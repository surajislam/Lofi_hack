## Telegram Username Search Web App

1. Clone repo.  
2. Install dependencies: `pip install -r requirements.txt`  
3. Set environment variables (`FLASK_SECRET_KEY`, `TELEGRAMBOTTOKEN`).  
4. Run: `python app.py`
